import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Brain, Mic, BarChart3, Video, Sparkles, Target, Clock, Shield,
  ArrowRight, Check, Star, Menu, Zap, Users
} from "lucide-react";
import heroImg from "@/assets/hero-interview.jpg";
import videoImg from "@/assets/feature-video.jpg";
import analyticsImg from "@/assets/feature-analytics.jpg";
import voiceImg from "@/assets/feature-voice.jpg";
import t1 from "@/assets/testimonial-1.jpg";
import t2 from "@/assets/testimonial-2.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MockMind AI — Master Every Interview with AI" },
      { name: "description", content: "Practice job interviews with the most advanced AI interviewer. Real-time feedback, voice analysis, and personalized coaching to land your dream job." },
      { property: "og:title", content: "MockMind AI — Master Every Interview" },
      { property: "og:description", content: "AI-powered mock interviews with real-time feedback." },
    ],
  }),
  component: Index,
});

function Nav() {
  return (
    <header className="fixed top-0 inset-x-0 z-50 glass">
      <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="size-8 rounded-lg bg-gradient-primary grid place-items-center shadow-glow">
            <Brain className="size-4 text-primary-foreground" />
          </div>
          <span className="font-display font-bold text-lg">MockMind<span className="text-gradient">.ai</span></span>
        </Link>
        <nav className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
          <a href="#features" className="hover:text-foreground transition">Features</a>
          <a href="#how" className="hover:text-foreground transition">How it works</a>
          <a href="#pricing" className="hover:text-foreground transition">Pricing</a>
          <a href="#testimonials" className="hover:text-foreground transition">Reviews</a>
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" className="hidden sm:inline-flex">Sign in</Button>
          <Button size="sm" className="bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow">
            Start Free
          </Button>
        </div>
      </div>
    </header>
  );
}

function Hero() {
  return (
    <section className="relative pt-32 pb-24 overflow-hidden">
      <div className="mx-auto max-w-7xl px-6 grid lg:grid-cols-2 gap-12 items-center">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs text-muted-foreground mb-6">
            <Sparkles className="size-3.5 text-accent" />
            Powered by next-gen interview intelligence
          </div>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.05]">
            Ace every interview with your <span className="text-gradient">AI coach</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground max-w-xl">
            Practice unlimited mock interviews with a hyper-realistic AI interviewer.
            Get instant feedback on your tone, body language, and answers — and walk into
            the real thing fully prepared.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button size="lg" className="bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow h-12 px-6">
              Start Free Interview <ArrowRight className="ml-2 size-4" />
            </Button>
            <Button size="lg" variant="outline" className="h-12 px-6 border-border bg-secondary/40">
              Watch Demo
            </Button>
          </div>
          <div className="mt-10 flex items-center gap-6 text-sm text-muted-foreground">
            <div className="flex -space-x-2">
              <img src={t1} alt="" width={32} height={32} className="size-8 rounded-full border-2 border-background object-cover" />
              <img src={t2} alt="" width={32} height={32} className="size-8 rounded-full border-2 border-background object-cover" />
              <div className="size-8 rounded-full border-2 border-background bg-gradient-primary grid place-items-center text-xs text-primary-foreground font-bold">+</div>
            </div>
            <div>
              <div className="flex items-center gap-1 text-accent">
                {[...Array(5)].map((_, i) => <Star key={i} className="size-3.5 fill-current" />)}
              </div>
              <p className="text-xs">Trusted by 50,000+ candidates</p>
            </div>
          </div>
        </div>
        <div className="relative">
          <div className="absolute -inset-8 bg-gradient-primary opacity-20 blur-3xl rounded-full" />
          <div className="relative rounded-2xl overflow-hidden shadow-elegant border border-border animate-float">
            <img src={heroImg} alt="AI mock interview session" width={1536} height={1024} className="w-full h-auto" />
          </div>
          <div className="absolute -bottom-6 -left-6 glass rounded-xl p-4 shadow-card hidden sm:block">
            <div className="flex items-center gap-3">
              <div className="size-10 rounded-lg bg-gradient-primary grid place-items-center animate-pulse-glow">
                <Zap className="size-5 text-primary-foreground" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Confidence Score</p>
                <p className="font-display font-bold text-xl">94%</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function Logos() {
  const logos = ["Google", "Meta", "Amazon", "Stripe", "Netflix", "Microsoft"];
  return (
    <section className="py-12 border-y border-border/60">
      <div className="mx-auto max-w-7xl px-6">
        <p className="text-center text-xs uppercase tracking-widest text-muted-foreground mb-8">
          Our users have landed roles at
        </p>
        <div className="flex flex-wrap justify-center items-center gap-x-12 gap-y-4 opacity-60">
          {logos.map((l) => (
            <span key={l} className="font-display text-xl md:text-2xl font-semibold">{l}</span>
          ))}
        </div>
      </div>
    </section>
  );
}

function Features() {
  const features = [
    { icon: Video, title: "Realtime Video Analysis", desc: "AI tracks your eye contact, posture, and facial expressions to coach you like a real interviewer.", img: videoImg },
    { icon: Mic, title: "Voice & Tone Intelligence", desc: "Detects filler words, pace, and confidence in your voice. Get clarity on how you really sound.", img: voiceImg },
    { icon: BarChart3, title: "Deep Performance Analytics", desc: "Track progress across hundreds of metrics. See exactly where you improved and what to fix.", img: analyticsImg },
  ];
  return (
    <section id="features" className="py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="max-w-2xl mx-auto text-center mb-16">
          <p className="text-sm text-accent font-medium mb-3">Features</p>
          <h2 className="text-4xl md:text-5xl font-bold">An interview lab in your pocket</h2>
          <p className="mt-4 text-muted-foreground">Everything you need to prepare for behavioral, technical, and case interviews — all powered by frontier AI.</p>
        </div>
        <div className="space-y-8">
          {features.map((f, i) => (
            <Card key={f.title} className="overflow-hidden border-border bg-card/60 backdrop-blur-sm">
              <div className={`grid lg:grid-cols-2 gap-0 items-center ${i % 2 ? "lg:[&>div:first-child]:order-2" : ""}`}>
                <div className="p-10 lg:p-14">
                  <div className="size-12 rounded-xl bg-gradient-primary grid place-items-center shadow-glow mb-6">
                    <f.icon className="size-6 text-primary-foreground" />
                  </div>
                  <h3 className="text-3xl font-bold mb-4">{f.title}</h3>
                  <p className="text-muted-foreground text-lg">{f.desc}</p>
                  <ul className="mt-6 space-y-2">
                    {["Instant scoring", "Actionable feedback", "Industry-specific questions"].map((b) => (
                      <li key={b} className="flex items-center gap-2 text-sm">
                        <Check className="size-4 text-accent" /> {b}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="relative h-full min-h-[320px]">
                  <img src={f.img} alt={f.title} loading="lazy" width={1280} height={896} className="w-full h-full object-cover" />
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

function HowItWorks() {
  const steps = [
    { icon: Target, title: "Choose your role", desc: "Pick from 500+ roles — from FAANG SWE to product manager to medical residency." },
    { icon: Brain, title: "Talk to the AI", desc: "Live conversation with a realistic AI interviewer that adapts to your answers in real time." },
    { icon: BarChart3, title: "Get your report", desc: "Receive a deep, frame-by-frame breakdown with scores and concrete next steps." },
  ];
  return (
    <section id="how" className="py-24 relative">
      <div className="mx-auto max-w-7xl px-6">
        <div className="max-w-2xl mx-auto text-center mb-16">
          <p className="text-sm text-accent font-medium mb-3">How it works</p>
          <h2 className="text-4xl md:text-5xl font-bold">From nervous to ready in minutes</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {steps.map((s, i) => (
            <Card key={s.title} className="p-8 bg-card/60 border-border relative overflow-hidden group hover:border-primary/50 transition">
              <div className="absolute top-4 right-6 text-7xl font-display font-bold text-primary/10 group-hover:text-primary/20 transition">
                0{i + 1}
              </div>
              <div className="size-12 rounded-xl bg-gradient-primary grid place-items-center shadow-glow mb-6">
                <s.icon className="size-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-bold mb-3">{s.title}</h3>
              <p className="text-muted-foreground text-sm">{s.desc}</p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

function Stats() {
  const stats = [
    { v: "50K+", l: "Interviews delivered" },
    { v: "94%", l: "Report better confidence" },
    { v: "3.2x", l: "Higher offer rate" },
    { v: "500+", l: "Role templates" },
  ];
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-6">
        <div className="rounded-3xl glass p-10 md:p-14 grid grid-cols-2 md:grid-cols-4 gap-8">
          {stats.map((s) => (
            <div key={s.l} className="text-center">
              <p className="text-4xl md:text-5xl font-display font-bold text-gradient">{s.v}</p>
              <p className="mt-2 text-sm text-muted-foreground">{s.l}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Testimonials() {
  const items = [
    { name: "Sarah Chen", role: "Product Manager @ Stripe", img: t1, quote: "I bombed three interviews before MockMind. After two weeks of practice I had offers from Stripe and Airbnb. The voice feedback alone was worth it." },
    { name: "Daniel Park", role: "Software Engineer @ Google", img: t2, quote: "It feels eerily like a real interview. The AI followed up on my answers in ways no other tool does. Got the offer on my first onsite." },
  ];
  return (
    <section id="testimonials" className="py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="max-w-2xl mx-auto text-center mb-16">
          <p className="text-sm text-accent font-medium mb-3">Loved by candidates</p>
          <h2 className="text-4xl md:text-5xl font-bold">Stories from the offer letter pile</h2>
        </div>
        <div className="grid md:grid-cols-2 gap-6">
          {items.map((t) => (
            <Card key={t.name} className="p-8 bg-card/60 border-border">
              <div className="flex items-center gap-1 text-accent mb-4">
                {[...Array(5)].map((_, i) => <Star key={i} className="size-4 fill-current" />)}
              </div>
              <p className="text-lg leading-relaxed">"{t.quote}"</p>
              <div className="mt-6 flex items-center gap-3">
                <img src={t.img} alt={t.name} loading="lazy" width={48} height={48} className="size-12 rounded-full object-cover" />
                <div>
                  <p className="font-semibold">{t.name}</p>
                  <p className="text-sm text-muted-foreground">{t.role}</p>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

function Pricing() {
  const plans = [
    { name: "Starter", price: "0", desc: "Try it out", features: ["3 interviews / month", "Basic feedback", "Standard question bank"] },
    { name: "Pro", price: "29", desc: "Most popular", featured: true, features: ["Unlimited interviews", "Video & voice analysis", "All 500+ role templates", "Detailed performance reports"] },
    { name: "Teams", price: "99", desc: "For coaches & schools", features: ["Everything in Pro", "Team dashboard", "Custom question banks", "Priority support"] },
  ];
  return (
    <section id="pricing" className="py-24">
      <div className="mx-auto max-w-7xl px-6">
        <div className="max-w-2xl mx-auto text-center mb-16">
          <p className="text-sm text-accent font-medium mb-3">Pricing</p>
          <h2 className="text-4xl md:text-5xl font-bold">Less than one coffee a week</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {plans.map((p) => (
            <Card key={p.name} className={`p-8 border-border relative ${p.featured ? "bg-gradient-primary text-primary-foreground shadow-elegant scale-[1.02]" : "bg-card/60"}`}>
              {p.featured && <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-background text-xs font-medium border border-border">Most Popular</div>}
              <p className={`text-sm font-medium ${p.featured ? "opacity-80" : "text-muted-foreground"}`}>{p.name}</p>
              <p className="mt-4 text-5xl font-display font-bold">${p.price}<span className="text-base font-normal opacity-70">/mo</span></p>
              <p className={`mt-2 text-sm ${p.featured ? "opacity-80" : "text-muted-foreground"}`}>{p.desc}</p>
              <Button className={`mt-6 w-full ${p.featured ? "bg-background text-foreground hover:bg-background/90" : "bg-gradient-primary text-primary-foreground"}`}>Get started</Button>
              <ul className="mt-6 space-y-3 text-sm">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-2"><Check className="size-4" /> {f}</li>
                ))}
              </ul>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTA() {
  return (
    <section className="py-24">
      <div className="mx-auto max-w-5xl px-6">
        <div className="rounded-3xl bg-gradient-primary p-12 md:p-20 text-center shadow-elegant relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.2),transparent_50%)]" />
          <div className="relative">
            <h2 className="text-4xl md:text-5xl font-bold text-primary-foreground">Your next interview is the one</h2>
            <p className="mt-4 text-primary-foreground/80 max-w-xl mx-auto">Join 50,000+ candidates training with MockMind. Free to start, no credit card required.</p>
            <Button size="lg" className="mt-8 h-12 px-8 bg-background text-foreground hover:bg-background/90">
              Start Your Free Interview <ArrowRight className="ml-2 size-4" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

function Footer() {
  return (
    <footer className="border-t border-border py-12">
      <div className="mx-auto max-w-7xl px-6 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
        <div className="flex items-center gap-2">
          <div className="size-6 rounded-md bg-gradient-primary grid place-items-center">
            <Brain className="size-3.5 text-primary-foreground" />
          </div>
          <span className="font-display font-semibold text-foreground">MockMind.ai</span>
        </div>
        <p>© 2026 MockMind AI. Crafted for the next great hire.</p>
        <div className="flex gap-5">
          <a href="#" className="hover:text-foreground">Privacy</a>
          <a href="#" className="hover:text-foreground">Terms</a>
          <a href="#" className="hover:text-foreground">Contact</a>
        </div>
      </div>
    </footer>
  );
}

function Index() {
  return (
    <div className="min-h-screen">
      <Nav />
      <main>
        <Hero />
        <Logos />
        <Features />
        <HowItWorks />
        <Stats />
        <Testimonials />
        <Pricing />
        <CTA />
      </main>
      <Footer />
    </div>
  );
}
